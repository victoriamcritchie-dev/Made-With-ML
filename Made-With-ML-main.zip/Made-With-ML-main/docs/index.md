## Documentation

- [madewithml](madewithml/data.md): documentation.

## Lessons

Learn how to combine machine learning with software engineering to design, develop, deploy and iterate on production ML applications.

- **Lessons**: [https://madewithml.com/](https://madewithml.com/#course)
- **Code**: [GokuMohandas/Made-With-ML](https://github.com/GokuMohandas/Made-With-ML)
