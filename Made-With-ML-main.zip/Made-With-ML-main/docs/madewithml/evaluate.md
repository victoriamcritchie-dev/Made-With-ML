::: madewithml.evaluate
